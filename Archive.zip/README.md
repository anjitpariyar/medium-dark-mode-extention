# medium-dark-mode-extention

##Load the Extension in Firefox

    -Open Firefox and go to about:debugging#/runtime/this-firefox.
    -Click on "Load Temporary Add-on...".
    -Select the manifest.json file from your medium-dark-mode-extention folder.

The extension should now be active on medium.com, and the custom styles will be applied whenever you visit the site.
